# Brandon Chan  
# chanbz@uci.edu
# 12383908

accessed_file = None
accessed_file_path = None
edit_requests = []
print_requests = []
admin = False